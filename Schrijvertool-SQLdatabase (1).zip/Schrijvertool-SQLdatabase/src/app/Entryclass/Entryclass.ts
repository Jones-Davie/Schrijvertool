export class Entryclass {
    constructor (

        public ID : number,
        public Name: string,
        public Type : string,
        public TypeTwo: string,
        public Entry : string,
        public Tags : string
    ) {}


}
