import { Entryclass } from '../Entryclass/Entryclass';

export const Wezensclassexample : Entryclass[] = [{
    ID: 4,
    Name: "Mens",
    Type: "Wezen",
    TypeTwo: "None",
    Entry: "Mensen zijn het regerende ras van Tellus. Levensspan: een normaal mens ongeveer 60 jaar, magiërs variërend tussen de 60 en geen natuurlijke dood.",
    Tags: "Mens"
},

{
    ID: 5,
    Name: "Anima",
    Type: "Wezen",
    TypeTwo: "None",
    Entry: "Een ziel of geest uit de Nevenwereld. Levensspan: geen natuurlijke dood.",
    Tags: "anima"
},

{
    ID: 6,
    Name: "Somnï",
    Type: "Wezen",
    TypeTwo: "None",
    Entry: "Wezens geschapen door de Zeven in de oude tijden. Zij waren met de Zeven verantwoordelijk voor de val van de mensheid.",
    Tags: "de Zeven, de Ene, Somnï"
}


]
