import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wezens',
  templateUrl: './wezens.component.html',
  styleUrls: ['./wezens.component.scss']
})
export class WezensComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
