import { Karakterclass } from '../Karakterclass/Karakterclass';

export const Karakterclassexample : Karakterclass[] = [{
    ID: 1,
    Name: "Cejrim",
    Type: "Hoofdkarakter",
    TypeTwo: "None",
    Entry: "Een man tussen de 20-28, donker haar en lichtbruine ogen",
    Tags: "magie, zwaard, mens"
},

{
    ID: 2,
    Name: "Nevyn",
    Type: "Hoofdkarakter",
    TypeTwo: "None",
    Entry: "Een vrouw tussen de 20-28, donker haar en oranje ogen",
    Tags: "anima, zwaard, mens"
},

{
    ID: 3,
    Name: "Valuïn",
    Type: "Bijkarakter",
    TypeTwo: "None",
    Entry: "Onbekend",
    Tags: "spoileralert"
}



]
